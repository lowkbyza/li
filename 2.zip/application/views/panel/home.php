<?php var_dump($_SESSION);?>
