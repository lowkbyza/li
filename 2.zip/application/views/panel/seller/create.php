<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
date_default_timezone_set('Asia/Bangkok');  ?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            
            
                
      <h3>
       สร้างบัญชี VPN-SSH
      </h3>
    <ol class="breadcrumb">
        <li><a href="<?= base_url('panel/reseller/'.$_SESSION['username'].'/server') ?>"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
		<li class="active">สร้างบัญชี</li>
    </ol>
    
        
        </div>
    </div><center>
    
           
            <div class="btn btn-primary" class="well"> มี <?= $user -> saldo ?> เครดิต </div>
           
        
     </center>
    <h4></h4>

            <div class="col-lg-12">
                <?php if (isset($message)) {echo $message; }?>
                  </div>
               
                    <div class="panel-body">
					<?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= $error ?></div>
					</div>
					<?php endif;?>
					<?= form_open() ?>
         
               
                <div class="panel panel-success">
                    <div class="panel-heading">
                        <b><center class="category text-gray">สร้างบัญชีสำหรับ [ <?= $server->ServerName ?> ]</center></b>
                    </div>
               
						<div align="center">
						<div class="form-group">
							<label for="username"><font color="000000">ชื่อผู้ใช้</font></label>
							<input type="text" name="username" class="form-control text-center" style="width:80%; border:5px" id="username" placeholder="อย่างน้อย 1ตัว ห้ามใช้ภาษาไทย" autofocus required/>
						</div>
						
                        <div class="form-group">
                            <label for="password"><font color="000000">รหัสผ่าน</font></label>
                            <input class="form-control text-center" style="width:80%; border:5px" type="text" name="password" id="password" placeholder="อย่างน้อย 1ตัว ห้ามใช้ภาษาไทย">
                        </div>
                    
                    <label for=""></label>
                    <div class="text-center">
                    <input type="submit" class="btn btn-success" style="width:80%; border:5px" value="สร้างบันชี"/>
                    </form>
                </div>
                </div>
            </div>
    </div>
</div>
     