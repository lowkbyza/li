<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<?php
$today= date("Y,m,d");
?>
<div id="page-wrapper">
	<div class="row">
        <div class="col-lg-12">
            <h3 class="page-header">บันชี VPN
            </h3>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <i class="fa fa-group fa-fw"></i> รายการบัญชี
                </div>
                
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
           
                            <thead>
                                <tr>
                                  <th><center>โฮส IP</center></th>
                                    <th><center>ชื่อผู้ใช้</center></th>
                                    <th><center>รหัสผ่าน</center></th>
                                    <th><center>ราคา</center></th>
                                    <th><center>สร้างวันที่</center></th>
                                    
                                    <th><center>วันหมดอายุ</center></th>
                                    <th><center> สถานะ</center></th>
                                   <th><center>โหลดไฟล์</center></th>
                                     
                                   
                                    <th><center>ลบออก</center></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(!empty($this)):?>
										<?php $jumlah=0; $counter=0; ?>
                                        <?php foreach ($this->user_model->get_account_list($_SESSION['username']) as $row): ?>
											<?php $counter++; ?>
                                            <tr>
                                               <td><center><?= $row['hostname']?></center></td>
                                                <td><center><?= $row['username'] ?></center></td>
                                                <td><center><?= $row['password'] ?></center></td>
                                                <td><center><?= $row['price']?></center></td>
                                                <td><center><?= $row['created_at']?></center></td>
                                                
                                                <td><center><?= $row['expired_at']?>
</center></td>
                                                <td> <?php
if ($today <= $row['expired_at'] ){
	?>
<center><script> 
var montharray=new Array("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec")
 
function countup(yr,m,d){
var today=new Date()
var todayy=today.getYear()
if (todayy < 1000)
todayy+=1900
var todaym=today.getMonth()
var todayd=today.getDate()
var todaystring=montharray[todaym]+" "+todayd+", "+todayy
var paststring=montharray[m-1]+" "+d+", "+yr
var difference=(Math.round((Date.parse(paststring)-Date.parse(todaystring))/(24*60*60*1000))*1)
difference+=" "
document.write(" เหลืออีก "+difference+" วัน")
}
//พิมพ์วันเรียงตามดังนี้  ( ปี ค.ศ./เดือน/วัน)
countup(<?= $row['expired_at']?>)
                  </script></center>
<?php
} else {
	echo '<center><font color="red">หมดอายุแล้ว</font></center>';
	?>
		
		<?php
	}
?></td>
                                                <td><center>
                                                    <a href="<?= base_url('panel/reseller/'.$_SESSION['username'].'/download') ?>" ><i class="fa fa-arrow-circle-down"></i></a>
                                            </center>    </td>
                                         <td><center>
                                                    <a href="<?= base_url('seller/delet_account/'. $row['id'])?>" ><i class="fa fa fa-bomb"></i></span>    </a>
                                            </center>    </td>
                                             </tr>
                                             <?php $jumlah = $jumlah + $row['price']; ?>
                                       <?php endforeach; ?>
                                    <?php else: ?>
                                   
                                        <tr>
                                            <td class="text-muted text-center" colspan="12"> ต้องเช่าก่อนถึ่งจะมีไฟล์ให้ดาวน์โหลด</td>
                                        </tr>
                                   <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
				<div class="panel-footer"> <?php if (isset($counter)) {echo 'จำนวนผู้ใช้  '. $counter; } ?> บัญชี / <?php if (isset($jumlah)) {echo 'ราคาทั้งหมด : '. $jumlah; } ?> บาท</div>
            </div>
        </div>
    </div>
</div>
