<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	
		
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h3>
       รายการเซิร์ฟเวอร์
      </h3>
    <ol class="breadcrumb">
        <li><a href="<?= base_url('home') ?>"><i class="fa fa-folder-open"></i>  อ่านข่าวสาร</a></li>
		<li class="active">หน้าหลัก</li>
    </ol>
    
            
 
    <!--[if lt IE 9]>                        
   <center>

 
<ol class="breadcrumb">
   <p><b>     <font color="red"> ชี้แจง !!!</b></p>
        
ลูกค้าต้องทำการสมัครโปรชั่นเสริมก่อนดังนี้</font>
	

												
<br>

📶 ทรูมูฟ สมัครTrueID👇👇<br>
9.63บาท  01วัน *900*3956# <a href="tel:*900*3956%23" > คลิกสมัคร...</a><br>
20.33บาท  07วัน *900*3957# <a href="tel:*900*3957%23" > คลิกสมัคร...</a><br>
63.13บาท  30วัน *900*3958# <a href="tel:*900*3958%23" > คลิกสมัคร...</a><br>
 <br>
<br>


📶 ดีแทค สมัคโปร viber👇👇<br>
05.35บาท  01วัน *104*600# <a href="tel:*104*600%23" > คลิกสมัคร...</a><br>
20.33บาท  07วัน *104*601# <a href="tel:*104*601%23" > คลิกสมัคร...</a><br>
52.43บาท  30วัน *104*602# <a href="tel:*104*602%23" > คลิกสมัคร...</a><br>
 <br>
       </ol></center>
    

</center>

		<![endif]-->
		
      
    </section>
            <div class="dropdown pull-right">
                <form method="post" action="/wallet/check.php">
                <?php foreach ($this->user_model->view_token() as $row): ?>
                    <input name="noty_wallet" type="hidden" value="<?= $row['wallet']; ?>" id="noty_wallet">
                        <?php endforeach; ?>
                <?php foreach ($this->user_model->view_wallet() as $row): ?>
                    <input name="phone" type="hidden" value="<?= $row['phone']; ?>" id="phone">
                        
                        <input name="passwd" type="hidden" value="<?= $row['passwd']; ?>" id="passwd">
                            <input name="email" type="hidden" value="<?= $row['email']; ?>" id="email">
                    <?php endforeach; ?>
                                      <?php foreach ($this->user_model->view_asset() as $row): ?>
                                         
                                       <input name="link" type="hidden" value="<?= $row['link']; ?>" id="link">
                                           <input name="web" type="hidden" value="<?= $row['web']; ?>" id="web">
                                               <input name="png" type="hidden" value="<?= $row['png']; ?>" id="png">
                                           <?php endforeach; ?>
                                               <input name="user" type="hidden" value="<?= $_SESSION['username'] ?>" id="user">
                     
                                      <input class="btn btn-warning" type="submit"  value="เติมเครดิต" />
                            
                                </form> 
					
            </div>
            
<div class="row">
       <div class="col-xs-6 col-md-5 col-md-4 col-lg-3">
            <div class="btn btn-primary" class="well">มี <B><?= $user -> saldo ?></B> เครดิต</div>
        </div>
    </div>
    <br>
    
       

    
    
  
    <div class="row">
            <div class="col-lg-12">
                <?php if (isset($message)) {echo $message; }?>
            </div>
        <?php foreach($server as $row): ?>
            
            <div class="col-sm-6 col-md-4 col-lg-3">
                <?php if ($row['Status']): ?>
                <div class="panel panel-success" >
                    <?php else: ?>
                    <div class="panel panel-danger" >
                    <?php endif; ?>
                    <div class="panel-heading" ><center>
                        <b><span class="fa fa-send fa-fw"></span><?= $row['ServerName']?></b></center>
                        
                            
                    
                    </div>
                    
                    <table class="table">
                        
                        
                        <tr>
                            <td><font color="#FF8100">ระยะเวลาใช้งาน</td><td>: <font color="#FFA800"><?= $row['Expired']?> วัน</td></font>
                        </tr>
                        <tr>
                            <td><font color="#0032FF">ราคา</td><td>:<font color="#0032FF"> <?= $row['Price']?> บาท</b></td></font>
                        </tr>
                        
                        <tr>
                            
								
                            <td><font color="#000000">สถานะ</td><td>: <font color="#19AC00"> ออนไลน์</b></font></td>
                        
								
                        </tr>
                        
                        
                    </table>
                    <div class="panel-footer text-left">
                        
                            
                       
  <?php if ($row['Status']): ?>
                    
                        
								<a class="form-control btn btn-success" href="<?= base_url('seller/buy/'.$row['Id']) ?>"><i class="fa fa-shopping-cart fa-fw"></i> เลือกเช่าเซิฟร์นี้ </a>
								<?php else: ?>
								<a class="form-control btn btn-danger" href="<?= base_url('seller/buy/'.$row['Id']) ?>"><i class="fa fa-lock"></i>  เซิฟร์เวอร์เต็ม </a>
								<?php endif; ?></div>
								
									
									
									
                   
                </div>
            </div>
        <?php endforeach; ?>
    </div>


<div class="form-control">
 <font color="red"><center>
     
    <?php
    

    
    $ip = $_SERVER["REMOTE_ADDR"];
$new =preg_replace('/^((\d+\.){3})(.*)/','\\1xxx',$ip);
echo "ที่อยู่ IP $new";
?>
	</font></center><br>
	
         <div>
             
            
                 
         </div>
         
             
             