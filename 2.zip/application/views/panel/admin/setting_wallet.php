<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	
<div id="page-wrapper">
	<div class="row">
        <div class="col-lg-12">
                   
      <h3>
       ตั้งค่า Wallet
      </h3>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
		<li class="active">ตั้งค่า Wallet</li>
    </ol>
    
        </div>
    </div>
    <div class="well"> 
    <div class="row">
        <center>
           
			  <?php if (isset($message)) {echo $message;} ?>
			  <?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= $error ?></div>
					</div>
			   <?php endif;?>
			   <?= form_open() ?>
				
				<?php foreach ($this->user_model->view_wallet() as $row): ?>
				
				<div class="form-group">
						<label for="phone">เบอร์ Wallet</label>
						<input type="text" name="phone" class="text-center form-control" id="phone" value="<?= $row['phone']?>"  placeholder="09xxxxxxxx" />
						</div>
					
				
					
						<div class="form-group">
						<label for="email">อีเมล Wallet</label>
						<input type="text" name="email" class="text-center form-control" id="email" value="<?= $row['email']?>"  placeholder="email@gmail.com" />
						</div>
						
					<div class="form-group">
						<label for="passwd">รหัสผ่าน Walllet</label>
						<input name="passwd" class="text-center form-control" id="passwd" type="password" value="<?= $row['passwd']?>" />
						</div>
						
					
					<!--[if lt IE 9]>
						<textarea id="wmd-input" class="wmd-input" name="post-text" cols="30%" rows="10%" tabindex="10%"></textarea>
						<![endif]-->
						<input type="submit" class="btn btn-primary form-control" value="อัปเดตข้อมูล"/>
					
			   </form></div></div>
			<?php endforeach; ?>
		   
		  