-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 24, 2018 at 07:49 PM
-- Server version: 5.5.60-0+deb8u1
-- PHP Version: 5.6.38-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sm_demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `asset`
--

CREATE TABLE `asset` (
  `id` int(11) NOT NULL,
  `png` mediumtext,
  `groud` varchar(50) DEFAULT NULL,
  `web` varchar(50) DEFAULT NULL,
  `link` varchar(50) DEFAULT NULL,
  `nohp` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `asset`
--

INSERT INTO `asset` (`id`, `png`, `groud`, `web`, `link`, `nohp`) VALUES
(1, 'https://cdn.pixelprivacy.com/wp-content/uploads/2017/10/VPN-Icon.png', 'https://www.facebook.com/groups/279863289432358', 'SM VPN-THAILAND', 'http://line.me/ti/p/%40cok9035j', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `data` blob NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `continent`
--

CREATE TABLE `continent` (
  `Id` int(11) NOT NULL,
  `Name` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `continent`
--

INSERT INTO `continent` (`Id`, `Name`) VALUES
(1, 'Asia'),
(2, 'North America'),
(3, 'Europe'),
(4, 'South America'),
(5, 'Africa'),
(6, 'Oceania');

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE `country` (
  `Id` int(11) NOT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Country` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`Id`, `Name`, `Country`) VALUES
(1, 'Asia', 'Singapore'),
(2, 'Asia', 'Indonesia'),
(3, 'Asia', 'Japan'),
(4, 'Asia', 'Hongkong'),
(5, 'Europe', 'Netherlands'),
(6, 'Europe', 'Germani'),
(7, 'Europe', 'France'),
(8, 'Europe', 'Luxembourg'),
(9, 'North-America', 'NY-USA'),
(10, 'North-America', 'Canada'),
(11, 'North-America', 'LA-USA'),
(12, 'South-America', 'NY-USA'),
(14, 'Africa', 'Johanesburg'),
(15, 'Oceania', 'Australia'),
(16, 'North-America', 'Austria');

-- --------------------------------------------------------

--
-- Table structure for table `deposit`
--

CREATE TABLE `deposit` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `pesan` text NOT NULL,
  `is_confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `jumlah` int(11) DEFAULT NULL,
  `created_at` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `histrory`
--

CREATE TABLE `histrory` (
  `NumberWallet` varchar(14) NOT NULL,
  `money` float NOT NULL,
  `username` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `NumberPhone` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `masseg`
--

CREATE TABLE `masseg` (
  `id` int(11) NOT NULL,
  `msg` mediumtext,
  `post` mediumtext
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `masseg`
--

INSERT INTO `masseg` (`id`, `msg`, `post`) VALUES
(1, 'ตัวอย่าง', '<b>สามารถเขียนเป็นภาษา<font color=\"red\"> html </font> ได้ </b>\r\n<h3>ขอบคุณที่ใช้บริการ</h3>');

-- --------------------------------------------------------

--
-- Table structure for table `ovpn`
--

CREATE TABLE `ovpn` (
  `id` int(11) NOT NULL,
  `server` varchar(50) DEFAULT NULL,
  `sim` varchar(50) DEFAULT NULL,
  `pro` varchar(50) DEFAULT NULL,
  `nohp` varchar(50) DEFAULT NULL,
  `link` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server`
--

CREATE TABLE `server` (
  `Id` int(11) NOT NULL,
  `HostName` varchar(50) DEFAULT NULL,
  `RootPasswd` varchar(25) NOT NULL,
  `MaxUser` int(11) NOT NULL DEFAULT '50',
  `Expired` int(11) NOT NULL DEFAULT '7',
  `ServerName` varchar(50) DEFAULT NULL,
  `Location` varchar(1000) DEFAULT NULL,
  `OpenSSH` varchar(50) NOT NULL DEFAULT '22',
  `Dropbear` varchar(50) NOT NULL DEFAULT '443',
  `Price` int(10) DEFAULT '10000',
  `Status` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sshuser`
--

CREATE TABLE `sshuser` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `hostname` varchar(50) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created_at` varchar(30) NOT NULL DEFAULT '',
  `expired_at` varchar(11) NOT NULL DEFAULT '30',
  `serverid` int(11) NOT NULL,
  `price` int(11) DEFAULT NULL,
  `password` varchar(50) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `token`
--

CREATE TABLE `token` (
  `id` int(11) NOT NULL,
  `login` varchar(50) DEFAULT NULL,
  `wallet` varchar(50) DEFAULT NULL,
  `add_vpn` varchar(50) DEFAULT NULL,
  `nohp` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `token`
--

INSERT INTO `token` (`id`, `login`, `wallet`, `add_vpn`, `nohp`) VALUES
(1, 'ใส่โทเคนแจ้งเตือนไลน์', 'ใส่โทเคนแจ้งเตือนไลน์', 'ใส่โทเคนแจ้งเตือนไลน์', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `username` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `avatar` varchar(255) DEFAULT 'default.jpg',
  `saldo` int(11) NOT NULL DEFAULT '0',
  `created_at` varchar(50) CHARACTER SET utf8 NOT NULL,
  `is_admin` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `is_confirmed` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `active` int(1) NOT NULL DEFAULT '1',
  `png` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '/asset/imega/userr.png'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `wallet`
--

CREATE TABLE `wallet` (
  `id` int(11) NOT NULL,
  `passwd` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `nohp` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wallet`
--

INSERT INTO `wallet` (`id`, `passwd`, `phone`, `email`, `nohp`) VALUES
(1, '1023020202', '06xxxxxxxx', 'email@gmail.com', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `asset`
--
ALTER TABLE `asset`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ci_sessions_timestamp` (`timestamp`);

--
-- Indexes for table `continent`
--
ALTER TABLE `continent`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `deposit`
--
ALTER TABLE `deposit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `masseg`
--
ALTER TABLE `masseg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ovpn`
--
ALTER TABLE `ovpn`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `server`
--
ALTER TABLE `server`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `sshuser`
--
ALTER TABLE `sshuser`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `token`
--
ALTER TABLE `token`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wallet`
--
ALTER TABLE `wallet`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `asset`
--
ALTER TABLE `asset`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `continent`
--
ALTER TABLE `continent`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `country`
--
ALTER TABLE `country`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `deposit`
--
ALTER TABLE `deposit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `masseg`
--
ALTER TABLE `masseg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ovpn`
--
ALTER TABLE `ovpn`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `server`
--
ALTER TABLE `server`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sshuser`
--
ALTER TABLE `sshuser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `token`
--
ALTER TABLE `token`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wallet`
--
ALTER TABLE `wallet`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
